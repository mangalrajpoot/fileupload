from django.shortcuts import render,redirect
from .models import FileUpload

# Create your views here.
def index(request):
    if request.method == 'GET':
        data=FileUpload.objects.all()
        return render(request,'home/index.html',{'data':data})
    elif request.POST and request.FILES['file']:
        file=request.FILES['file']
        data=FileUpload(image=file)
        data.save()
        return redirect('/')
        

