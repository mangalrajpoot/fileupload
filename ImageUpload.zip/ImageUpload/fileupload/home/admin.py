from django.contrib import admin
from .models import FileUpload

# Register your models here.
admin.site.register(FileUpload)
